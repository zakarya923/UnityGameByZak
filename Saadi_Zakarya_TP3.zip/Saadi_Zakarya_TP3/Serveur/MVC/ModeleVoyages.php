<?php
declare (strict_types=1);
class voyages
{
    private $idvoy;
    private $image;
    private $description;
    private $destination;
    private $date_depart;
    private $date_fin;
    private $lieu_depart;
    private $prix;


    function __construct(int $idvoy, ?string $image, string $description, string $destination, string $date_depart, string $date_fin, string $lieu_depart, int $prix) 
    {
        $this->idvoy = $idvoy;
        $this->image = $image;
        $this->description = $description;
        $this->destination = $destination;
        $this->date_depart = $date_depart;
        $this->date_fin = $date_fin;
        $this->lieu_depart = $lieu_depart;
        $this->prix = $prix;
    }

    function getIdV():int {
        return $this->idvoy;
    }
    function getImage():string {
        return $this->image;
    }
    function getDescription():string {
        return $this->description;
    }
    function getdestination():string {
        return $this->destination;
    }
    function getdate_depart():string {
        return $this->date_depart;
    }
    function getdate_fin():string {
        return $this->date_fin;
    }
    
    function getlieu_depart():string {
        return $this->lieu_depart;
    }
    
    function getprix():int {
        return $this->prix;
    }

    function setIdV($idvoy):void {
        $this->idvoy = $idvoy;
    }
    function setimage($image):void {
        $this->image = $image;
    }
    function setdescription($description):void {
        $this->description = $description;
    }
    function setdestination($destination):void {
        $this->destination = $destination;
    }
    function setdate_depart($date_depart):void {
        $this->date_depart = $date_depart;
    }

    function setdate_fin($date_fin):void {
        $this->date_fin = $date_fin;
    }
    function setlieu_depart($lieu_depart):void {
        $this->lieu_depart = $lieu_depart;
    }
    function setprix($prix):void {
        $this->prix = $prix;
    }
}
?>