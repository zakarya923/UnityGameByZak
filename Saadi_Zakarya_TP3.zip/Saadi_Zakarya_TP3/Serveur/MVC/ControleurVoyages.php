<?php
declare(strict_types=1);
require_once("ModeleVoyages.php");
require_once("ModeleConnexions.php");
require_once("ModeleMembres.php");
require_once("DAO.php");

class ControleurVoyage
{
    static private $instanceCtr = null;
    private $reponse;
    private function __construct()
    {

    }

    // Retourne le singleton du contrôleur
    static function getControleurVoyage(): ControleurVoyage
    {
        // Vérifier si l'instance du contrôleur de voyage existe déjà
        if (self::$instanceCtr == null) {
            // Si l'instance n'existe pas, en créer une nouvelle
            self::$instanceCtr = new ControleurVoyage();
        }

        // Retourner l'instance du contrôleur de voyage
        return self::$instanceCtr;
    }

    function CtrV_Enregistrer()
    {
        // Récupérer la valeur du champ 'image' s'il est défini, sinon une chaîne vide
        $image = isset($_POST['image']) ? $_POST['image'] : '';
        

        // Convertir la valeur du champ 'prix' en entier
        $prix = intval($_POST['prix']);

        

        // Créer un nouvel objet voyage avec les valeurs des champs du formulaire
        $voyage = new voyages(
            0,
            // ID 0 (supposant que 0 signifie un nouvel enregistrement)
            $image,
            $_POST['description'],
            $_POST['destination'],
            $_POST['date_depart'],
            $_POST['date_fin'],
            $_POST['lieu_depart'],
            $prix
        );

        // Appeler la méthode MdlV_Enregistrer du DAO pour enregistrer le voyage
        return DAO::getDao()->MdlV_Enregistrer($voyage);
    }

    function CtrV_getAll()
    {
        return DAO::getDao()->MdlV_getAll();
    }

    function CtrV_getAllMembres()
    {
        return DAO::getDao()->MdlV_getAllMembres();
    }

    function CtrV_MAJ()
    {
        return DAO::getDao()->modifier();
    }

    function CtrV_MAJmembres(): string
    {
        return DAO::getDao()->modifierMembres();
    }

    function CtrV_Supp(int $idvoy): string
    {
        return DAO::getDao()->MdlV_Supprimer($idvoy);
    }

    function CtrV_fiche(int $idvoy): string
    {
        return DAO::getDao()->fiche($idvoy);
    }

    function CtrV_ficheMembres(int $idm): string
    {
        return DAO::getDao()->ficheMembres($idm);
    }

    function CtrV_Actions()
    {
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
            switch ($action) {
                case "enregistrer":

                    return $this->CtrV_Enregistrer();

                case "fiche":
                    if (isset($_POST['idVoyage'])) {
                        $idvoy = intval($_POST['idVoyage']);
                        return $this->CtrV_fiche($idvoy);
                    }

                case "ficheMembres":
                        if (isset($_POST['idMembres'])) {
                            $idm = intval($_POST['idMembres']);
                            return $this->CtrV_ficheMembres($idm);
                        }
                
                case "modifier":

                    return $this->CtrV_MAJ();

                case "modifierMembres":
                
                        return $this->CtrV_MAJmembres();
                    

                case "enlever":
                    if (isset($_POST['idVoyage'])) {
                        $idvoy = intval($_POST['idVoyage']);
                        return $this->CtrV_Supp($idvoy);
                    }

                case "lister":
                    return $this->CtrV_getAll();

                case "listerMembres":
                        return $this->CtrV_getAllMembres();

                case "listercards":
                    return $this->CtrV_getAll();
                
                case "listercardsMembres":
                        return $this->CtrV_getAll();

                case "listerVoyagePanier":
                    return $this->CtrV_getAll();

            }


        }


    }


}   

?>