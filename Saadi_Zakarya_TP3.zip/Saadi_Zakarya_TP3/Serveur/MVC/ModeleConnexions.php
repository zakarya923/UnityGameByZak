<?php
declare(strict_types=1);

class Connexions
{
    private $idcm;
    private $courriel;
    private $password;
    private $role;
    private $statut;

    public function __construct(int $idcm, string $courriel, string $password, string $role, string $statut)
    {
        $this->idcm = $idcm;
        $this->courriel = $courriel;
        $this->password = $password;
        $this->role = $role;
        $this->statut = $statut;
    }

    public function getIdcm(): int
    {
        return $this->idcm;
    }

    public function getCourriel(): string
    {
        return $this->courriel;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function getRole(): string
    {
        return $this->role;
    }

    public function getStatut(): string
    {
        return $this->statut;
    }

    public function setIdcm(int $idcm): void
    {
        $this->idcm = $idcm;
    }

    public function setCourriel(string $courriel): void
    {
        $this->courriel = $courriel;
    }

    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    public function setRole(string $role): void
    {
        $this->role = $role;
    }

    public function setStatut(string $statut): void
    {
        $this->statut = $statut;
    }
}
?>