<?php
declare(strict_types=1);

class Membres
{
    private $idm;
    private $nom;
    private $prenom;
    private $courriel;
    private $sexe;
    private $dateNaissance;

    public function __construct(int $idm, string $nom, string $prenom, string $courriel, string $sexe, string $dateNaissance)
    {
        $this->idm = $idm;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->courriel = $courriel;
        $this->sexe = $sexe;
        $this->dateNaissance = $dateNaissance;
    }

    public function getIdm(): int
    {
        return $this->idm;
    }

    public function getNom(): string
    {
        return $this->nom;
    }

    public function getPrenom(): string
    {
        return $this->prenom;
    }

    public function getCourriel(): string
    {
        return $this->courriel;
    }

    public function getSexe(): string
    {
        return $this->sexe;
    }

    public function getDateNaissance(): string
    {
        return $this->dateNaissance;
    }

    public function setIdm(int $idm): void
    {
        $this->idm = $idm;
    }

    public function setNom(string $nom): void
    {
        $this->nom = $nom;
    }

    public function setPrenom(string $prenom): void
    {
        $this->prenom = $prenom;
    }

    public function setCourriel(string $courriel): void
    {
        $this->courriel = $courriel;
    }

    public function setSexe(string $sexe): void
    {
        $this->sexe = $sexe;
    }

    public function setDateNaissance(string $dateNaissance): void
    {
        $this->dateNaissance = $dateNaissance;
    }
}
?>