<?php
session_start();

require_once(__DIR__ . "/../BD/AcceesBD.php");
require_once("ModeleVoyages.php");
require_once("ModeleConnexions.php");
require_once("ModeleMembres.php");

class DAO
{
    static private $modelVoyage = null;
    private $reponse = array();
    private $connexion = null;

    private function __construct()
    {

    }

    // Retourne le singleton du modèle
    static function getDao(): DAO
    {
        if (self::$modelVoyage == null) {
            self::$modelVoyage = new DAO();
        }
        return self::$modelVoyage;
    }

    function MdlV_Enregistrer(voyages $voyage): string
    {
        $connexion = Connexion::getConnexion();
        $requete = "INSERT INTO voyages (id, image, description, destination, date_depart, date_fin, lieu_depart, prix) VALUES (0, ?, ?, ?, ?, ?, ?, ?)";
        $image="avatar.png";
        $dossier="../../../Client/public/images/";
	    if($_FILES['image']['tmp_name']!==""){
		$nomImage=sha1($voyage->getDescription().time());
		//Upload de la photo
		$tmp = $_FILES['image']['tmp_name'];
		$fichier= $_FILES['image']['name'];
		$extension=strrchr($fichier,'.');
		@move_uploaded_file($tmp,$dossier.$nomImage.$extension);
		// Enlever le fichier temporaire chargé
		@unlink($tmp); //effacer le fichier temporaire
		$image=$nomImage.$extension;}
        try {
            $stmt = $connexion->prepare($requete);
            $stmt->execute([
                $voyage->getImage(), $voyage->getDescription(), $voyage->getdestination(), $voyage->getdate_depart(),
                $voyage->getdate_fin(), $voyage->getlieu_depart(), $voyage->getprix()
            ]);
            $this->reponse['msg'] = "Voyage bien crée";
            $this->reponse['OK'] = true;

        } catch (Exception $e) {
            $this->reponse['OK'] = false;
            $this->reponse['msg'] = "Problème pour enregistrer le voyage: ";
            $this->reponse['errorInfo'] = $stmt->errorInfo();

        } finally {
            unset($connexion);
            return json_encode($this->reponse);
        }
        return "";
    }

    function MdlV_getAll(): string
    {
        $connexion = Connexion::getConnexion();
        $requete = "SELECT * FROM voyages";
        try {
            $stmt = $connexion->prepare($requete);
            $stmt->execute();
            $listeVoyages = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $this->reponse['OK'] = true;
            $this->reponse['msg'] = "";
            $this->reponse['listeVoyages'] = $listeVoyages;
        } catch (Exception $e) {
            $this->reponse['OK'] = false;
            $this->reponse['msg'] = "Problème pour obtenir les données des voyages";
        } finally {
            unset($connexion);
            return json_encode($this->reponse);
        }
        return "";
    }

    function MdlV_getAllMembres(): string
    {
        $connexion = Connexion::getConnexion();
        $requete = "SELECT Idm, Nom,Prenom, statut, rôle FROM membres INNER JOIN connexions ON Idm = connexions.Idcm;";
        try {
            $stmt = $connexion->prepare($requete);
            $stmt->execute();
            $listeMembres = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $this->reponse['OK'] = true;
            $this->reponse['msg'] = "";
            $this->reponse['listeMembres'] = $listeMembres;
        } catch (Exception $e) {
            $this->reponse['OK'] = false;
            $this->reponse['msg'] = "Problème pour obtenir les données des Membres";
        } finally {
            unset($connexion);
            return json_encode($this->reponse);
        }
        return "";
    }

    function fiche(int $idvoy){
    $connexion = Connexion::getConnexion();
    $requete = "SELECT * FROM voyages WHERE id = ?";
    
    try {
        $stmt = $connexion->prepare($requete);
        $stmt->execute([$idvoy]);

        $fiche = $stmt->fetch(PDO::FETCH_OBJ);
        if ($fiche) {
            $reponse['fiche'] = $fiche;
            $reponse['OK'] = true;
        } else {
            $reponse['OK'] = false;
        }
        
        $reponse['action'] = "fiche";
    } catch (Exception $e) {
        // Gérer l'exception
    } finally {
        unset($connexion);
        return json_encode($reponse);
    }
    return "";
    }

    
    function modifier()
    {
        $connexion = Connexion::getConnexion();
        $idVoyage = $_POST['id'];
        $destination = $_POST['destination'];
        $description = $_POST['description'];
        $date_depart = $_POST['date_depart'];
        $date_fin = $_POST['date_fin'];
        $lieu_depart = $_POST['lieu_depart'];
        $prix = $_POST['prix'];
        
        $requete = "UPDATE voyages SET destination = ?, description = ?, date_depart = ?, date_fin = ?, lieu_depart = ?, prix = ? WHERE id = ?";
       
        try {

            $stmt = $connexion->prepare($requete);
            $stmt->execute([$destination, $description, $date_depart, $date_fin, $lieu_depart, $prix, $idVoyage]);

            $this->reponse['msg'] = "Voyage $idVoyage bien modifié";
            $this->reponse['OK'] = true;
        } catch (Exception $e) {
            $this->reponse['msg'] = "Problème lors de la modification du voyage";
            $this->reponse['OK'] = false;
        }
        finally {
            unset($connexion);
            return json_encode( $this->reponse);
        }
    }

    function ficheMembres(int $idm){
        $connexion = Connexion::getConnexion();
        $requete = "SELECT Idm, Nom,Prenom, statut, rôle FROM membres INNER JOIN connexions ON Idm = connexions.Idcm WHERE Idm = ?;;";
        
        try {
            $stmt = $connexion->prepare($requete);
            $stmt->execute([$idm]);
    
            $fiche = $stmt->fetch(PDO::FETCH_OBJ);
            if ($fiche) {
                $reponse['ficheMembres'] = $fiche;
                $reponse['OK'] = true;
            } else {
                $reponse['OK'] = false;
            }
            
            $reponse['action'] = "ficheMembres";
        } catch (Exception $e) {
            // Gérer l'exception
        } finally {
            unset($connexion);
            return json_encode($reponse);
        }
        return "";
        }


    function modifierMembres(): string
    {
        $connexion = Connexion::getConnexion();
        $idm = $_POST['idm'];
        $statut = $_POST['statut'];
        $role = $_POST['rôle'];

    
        $requete = "UPDATE connexions JOIN membres ON connexions.Idcm = membres.Idm SET connexions.statut = ?, connexions.rôle = ? WHERE membres.Idm = ?;";
    
        try {

    
            $stmt = $connexion->prepare($requete);
            $stmt->execute([$statut, $role, $idm]);
    
            $this->reponse['msg'] = "Membre $idm bien modifié";
            $this->reponse['OK'] = true;
        } catch (Exception $e) {
            $this->reponse['msg'] = "Problème lors de la modification du membre";
            $this->reponse['OK'] = false;
        } finally {
            unset($connexion);
            return json_encode($this->reponse);
        }
        return "";
    }

    function MdlV_Supprimer(int $idvoy): string
    {
        $connexion = Connexion::getConnexion();

        $requete = "DELETE FROM voyages WHERE id = ?";
        try {
            $stmt = $connexion->prepare($requete);
            $stmt->execute([$idvoy]);

            $this->reponse['OK'] = true;
            $this->reponse['msg'] = "Voyage supprimé avec succès";
        } catch (Exception $e) {
            $this->reponse['OK'] = false;
            $this->reponse['msg'] = "Problème lors de la suppression du voyage";
        } finally {
            unset($connexion);
            return json_encode($this->reponse);
        }
        return "";
    }
}
?>