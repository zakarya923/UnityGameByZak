<?php
require_once(__DIR__ ."/../BD/AcceesBD.php");
$reponse = array();
function MdlV_getAll(): string
{
$connexion = Connexion::getConnexion();
$requete = "SELECT * FROM voyages";
try {
    $stmt = $connexion->prepare($requete);
    $stmt->execute();
    $listeVoyages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $reponse['OK'] = true;
    $reponse['msg'] = "";
    $reponse['listeVoyages'] = $listeVoyages;
} catch (Exception $e) {
    $reponse['OK'] = false;
    $reponse['msg'] = "Problème pour obtenir les données des voyages";
} finally {
    unset($connexion);
    return json_encode($reponse);
}
return "";
}
?>