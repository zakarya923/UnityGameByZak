<?php
  // define("SERVEUR","localhost");
  // define("USAGER","root");
  // define("PASSE","");
  // define("BD","bdcircuits");
  $SERVEUR = "localhost";
	$USAGER = "root";
	$PASS = "";
	$BD = "bdcircuits";
?>