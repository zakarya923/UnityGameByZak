<?php
declare (strict_types=1);

require_once("Connexion.php");

// Patron de conception Singleton
class Connexion{
	private static $connexion=null;
	
	// Interdire de créer des objets Connexion par l'extérieur de la classe
	private function __construct(){}

	
	// Retourne le singleton de la connexion
	static function getConnexion():PDO {
		if(self::$connexion == null){
			self::connecter();
		}
		return self::$connexion;
	}

	
	// Créer la connexion
	private static function connecter():void {
		global $SERVEUR, $BD, $USAGER, $PASS;
		try {
			$dns = "mysql:host=$SERVEUR;dbname=$BD";
			$options = array(
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
			);
			self::$connexion = new PDO( $dns, $USAGER, $PASS, $options );
			} catch ( Exception $e ) {
				echo $e->getMessage();
				echo "Probleme de connexion au serveur de bd";
				exit();
			}
	}	
	function enleverFichier($dossier,$pochette){
		if($pochette!=="logoProjet.png"){
			$rmPoc="../$dossier/".$pochette;
			$tabFichiers = glob("../$dossier/*");
			//print_r($tabFichiers);
			// parcourir les fichier
			foreach($tabFichiers as $fichier){
			if(is_file($fichier) && $fichier==trim($rmPoc)) {
				// enlever le fichier
				unlink($fichier);
				break;
			}
			}
		}
	}
		
	function verserFichier($dossier, $inputNom, $fichierDefaut, $chaine){
		$cheminDossier="../$dossier/";
		$nomPochette=sha1($chaine.time());
		$pochette=$fichierDefaut;
		if($_FILES[$inputNom]['tmp_name']!==""){
			if($pochette !== "logoProjet.pngx"){
				$this->enleverFichier($dossier,$pochette);//Modifier
			}
			//Upload de la photo
			$tmp = $_FILES[$inputNom]['tmp_name'];
			$fichier= $_FILES[$inputNom]['name'];
			$extension=strrchr($fichier,'.');
			@move_uploaded_file($tmp,$cheminDossier.$nomPochette.$extension);
			// Enlever le fichier temporaire chargé
			@unlink($tmp); //effacer le fichier temporaire
			//Enlever l'ancienne pochette dans le cas de modifier
			$pochette=$nomPochette.$extension;
			//$this->enleverFichier($dossier,$pochette);
			
		}
		return $pochette;
	}
}
?>