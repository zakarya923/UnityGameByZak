-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- HÃ´te : 127.0.0.1:3306
-- GÃ©nÃ©rÃ© le : dim. 28 mai 2023 Ã  20:18
-- Version du serveur : 8.0.31
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
CREATE DATABASE IF NOT EXISTS `bdcircuits` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bdcircuits`;

--
-- Base de donnÃ©es : `bdcircuits`
--

-- --------------------------------------------------------
--
-- Structure de la table `membres`
--

DROP TABLE IF EXISTS `membres`;
CREATE TABLE IF NOT EXISTS `membres` (
  `Idm` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50),
  `Courriel` varchar(250) NOT NULL,
  `Sexe` varchar(50) NOT NULL,
  `DateNaissance` date NOT NULL,
  PRIMARY KEY (`Idm`)
) ENGINE=MyISAM AUTO_INCREMENT=10 ;

--
-- DÃ©chargement des donnÃ©es de la table `membres`
--

INSERT INTO `membres` (`Idm`, `Nom`, `Prenom`, `Courriel`, `Sexe`, `DateNaissance`) VALUES
(1, 'Saadi', 'Zak', 'admin@NomDeVotreCompagnie.com', 'M', '2014-05-20'),
(10, 'Saadi', 'Zakarya', 'zakarya923@gmail.com', 'M', '2014-10-09');

-- --------------------------------------------------------
--
-- Structure de la table `connexions`
--

DROP TABLE IF EXISTS `connexions`;
CREATE TABLE IF NOT EXISTS `connexions` (
  `Idcm` int NOT NULL,
  `courriel` varchar(150) NOT NULL,
  `Password` varchar(20)  NOT NULL,
  `rôle` varchar(50) NOT NULL,
  `statut` varchar(50) NOT NULL,
  CONSTRAINT `connexion_idc_FK` FOREIGN KEY (`Idcm`) REFERENCES `membres` (`idm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- DÃ©chargement des donnÃ©es de la table `connexions`
--

INSERT INTO `connexions` (`Idcm`, `courriel`, `Password`, `rôle`, `statut`) VALUES
(1, 'admin@NomDeVotreCompagnie.com', 'admin', 'A', 'A');
INSERT INTO `connexions` (`Idcm`, `courriel`, `Password`, `rôle`, `statut`) VALUES
(10, 'zakarya923@gmail.com', '12345', 'M', 'A');
-- --------------------------------------------------------

CREATE TABLE `voyages` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `date_depart` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `lieu_depart` varchar(100) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- DÃ©chargement des donnÃ©es de la table `voyages`
--

INSERT INTO `voyages` (`id`, `image`, `description`, `destination`, `date_depart`, `date_fin`, `lieu_depart`, `prix`) VALUES
(9, '', 'Aller la bas', 'Maroc', '2023-07-10', '2023-07-25', 'France', '5450.00'),
(10, '', 'Aller la bas aussi', 'Tanzanie', '2023-07-26', '2023-07-31', 'France', '4321.00'),
(11, '', 'DJKJNDJKND', 'Tunisie', '2023-07-27', '2023-07-31', 'Maroc', '5674.00'),
(12, '', 'JDXNIN', 'Comores', '2023-07-02', '2023-07-24', 'Maltes', '5678.00'),
(13, '', 'Bon Voyage', 'Bresil', '2023-07-10', '2023-07-31', 'France', '234');



--
-- Index pour les tables dÃ©chargÃ©es
--

--
-- Index pour la table `voyages`
--
ALTER TABLE `voyages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables dÃ©chargÃ©es
--

--
-- AUTO_INCREMENT pour la table `voyages`
--
ALTER TABLE `voyages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
