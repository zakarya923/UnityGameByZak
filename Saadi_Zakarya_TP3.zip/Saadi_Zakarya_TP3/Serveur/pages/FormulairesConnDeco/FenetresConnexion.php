<?php
session_start();
require_once("../../BD/AcceesBD.php");

$courriel = $_POST['courriel'];
$pass = $_POST['Password'];

$connexion = Connexion::getConnexion();

$requete = "SELECT connexions.*, membres.Nom, membres.Prenom FROM connexions  JOIN membres  ON connexions.Idcm = membres.Idm WHERE connexions.courriel = ? AND connexions.Password = ?";
$stmt = $connexion->prepare($requete);
$stmt->execute([$courriel, $pass]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$result) { //Si pas trouvé
    echo "SVP vérifiez vos paramètres de connexion";
    $stmt->closeCursor();
    exit;
}
if ($result['statut'] == "A") {
    if ($result['rôle'] == "M") {
        $_SESSION['usager'] = "M";
        $_SESSION['nom'] = $result['Nom'];
        $_SESSION['prenom'] = $result['Prenom'];
        header('Location: ../FenetreMembre/PageAcceuilMembre.php');
        exit;
    } else if ($result['rôle'] == "A") {
        $_SESSION['usager'] = "A";
        header('Location: ../FenetreAdmin/PageAcceuilAdmin.php');
        exit;
    }
} else {
    header('Location: ../../../index.php?msg=Problème+avec+votre+compte.+Contactez+l\'administrateur');
    exit;
}
?>