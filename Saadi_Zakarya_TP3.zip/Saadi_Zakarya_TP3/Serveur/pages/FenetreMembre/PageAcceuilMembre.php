<?php
session_start();
if (isset($_SESSION['usager']) && $_SESSION['usager'] == "M") {
    $prenom = $_SESSION['prenom'];
    $nom = $_SESSION['nom'];
    echo '<div style="text-align: center; margin-top: 5px;">
            <h2>Bienvenue, ' . $prenom . ' ' . $nom . '</h2>
          </div>';
    echo '<div id="messageImportant" class="alert alert-warning alert-dismissible fade show" style="width: 23%;" role="alert" >
            <span class="text-center">Reinitialisez le panier avec "Effacer Panier" !</span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
} else {
    header('Location: ../../../index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Membre</title>
    <link id="ic" rel="icon" href="../../../Client/public/Icone/logoProjet.ico" type="image/x-icon">
    <link rel="stylesheet" href="../../../Client/public/CSS/stylePageMembre.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../../../Script/FormulaireValid.js"></script>
    <script src="../../../Client/public/Vue/VueVoyages.js"></script>
    <script src="../../../Client/public/Vue/VoyagesRequetes.js"></script>
    <script>
        let chargerVoyages = () => {

            $.ajax({
                type: "POST",
                url: "../FenetreAdmin/Actionneur.php",
                data: { "action": "listercardsMembres" },
                dataType: "json",
                success: (listeVoyages) => {
                    montrerVue("listercardsMembres", listeVoyages);
                },
                error: (xhr, status, error) => {
                    console.log(xhr.responseText);
                }
            });
        }
        document.addEventListener("DOMContentLoaded", chargerVoyages);
    </script>

</head>

<body>
    <!-- -------------------------------------------------MENU---------------------------------------------------- -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid ">
            <a class="navbar-brand" href="#">
                <img id="logoAdmin" src="../../../Client/public/images/logoProjet.png" alt="Logo" class="logo">
            </a>
            <a class="navbar-brand" href="#">Menu</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page">Profil</a>
                    </li>

                    <li class="nav-item " id="Deco">
                        <a class="nav-link" href="javascript:remettrePanierZero();">Effacer le panier</a>
                    </li>

                    <li class="nav-item" id="Deco">
                        <a class="nav-link" href="../../../index.php">Deconnexion</a>
                    </li>

                </ul>
                <div class="right-align d-flex align-items-center justify-content-center" id="Panier">
                    <a id="pa" class="nav-link" href="javascript:chargerVoyagesPanier();">
                        <i class="fa-solid fa-basket-shopping fa-beat fa-xl" style="color: #000000;"></i>
                    </a>
                    &nbsp;&nbsp;
                    <span id="nbart">(0)</span>
                </div>
            </div>
        </div>
    </nav>
    <div class="container" id="affichercardsMembres">

    </div>
    <div id="paiement" class="modal fade" tabindex="-1" aria-labelledby="paiementLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paiementLabel">Paiement effectué</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Merci pour votre paiement.
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" onclick="remettrePanierZero()">Fermer</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="idModPanier" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="contenuPanier"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="msg" id="msg">

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> -->
</body>

</html>