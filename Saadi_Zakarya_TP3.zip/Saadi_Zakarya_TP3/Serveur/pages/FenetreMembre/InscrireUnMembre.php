<?php
session_start();
require_once("../../BD/AcceesBD.php");

$nom = $_POST['Nom'];
$prenom = $_POST['Prenom'];
$courriel = $_POST['Courriel'];
$mdp = $_POST['Pass'];
$sexe = $_POST['Sexe'];
$Datenaissance = $_POST['DateNaissance'];

$connexion = Connexion::getConnexion();
 //Requetes d'insertion dans la tables membres

 $requete = "INSERT INTO membres (Idm, Prenom, Nom, Courriel, Sexe, DateNaissance) VALUES (0, ?, ?, ?, ?, ?)";
 $stmt = $connexion->prepare($requete);
 $stmt->execute([$prenom, $nom, $courriel, $sexe, $Datenaissance]);
 $idm = $connexion->lastInsertId();


//Requetes d'insertion dans la tables connexion
$requete = "INSERT INTO connexions (Idcm, courriel, Password, rôle, statut) VALUES (?, ?, ?, 'M', 'A')";
$stmt = $connexion->prepare($requete);
$stmt->execute([$idm, $courriel, $mdp]);
$icdm = $connexion->lastInsertId();
header('Location:../../../index.php');
exit;
?>