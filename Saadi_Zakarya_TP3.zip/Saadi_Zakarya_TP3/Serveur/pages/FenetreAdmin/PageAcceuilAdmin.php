<?php
session_start();

if (!isset($_SESSION['usager'])) {
    header('Location: ../../../index.php?msg=Problème+avec+votre+connexion');
    exit;
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin</title>
    <link id="ic" rel="icon" href="../../../Client/public/Icone/logoProjet.ico" type="image/x-icon">
    <link rel="stylesheet" href="../../../Client/public/CSS/stylePageAdmin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../../../Script/FormulaireValid.js"></script>
    <script src="../../../Client/public/Vue/VueVoyages.js"></script>
    <script src="../../../Client/public/Vue/VoyagesRequetes.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <!-- <script src="../../../Client/public/js/MonJs.js"></script> -->

</head>

<body>
    <!-- -------------------------------------------------MENU---------------------------------------------------- -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid ">
            <a class="navbar-brand" href="#">
                <img id="logoAdmin" src="../../../Client/public/images/logoProjet.png" alt="Logo" class="logo">
            </a>
            <a class="navbar-brand" href="#">Menu</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="javascript: montrerFormEnreg();">Cree Circuit</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript: chargerVoyagesAJAX()">Gerer les circuits</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="javascript: chargerMembresAJAX()">Gerer les membres</a>
                    </li>

                    <li class="nav-item" id="Deco">
                        <a class="nav-link" href="../../../index.php">Deconnexion</a>
                    </li>
                </ul>
                <div class="right-align">
                    <?php echo 'Connecté(e) en tant que: <span>' . $_SESSION['usager'] . '</span>'; ?>

                </div>
            </div>
        </div>
    </nav>
    <div class="container" id="contenu">
    </div>
    <div class="msg" id="msg">

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> -->
</body>

</html>