<?php
	require_once("../../BD/AcceesBD.php");
	$idArticle=$_POST['idar'];	
	$requete="SELECT * FROM articles WHERE ida=?";
	$stmt = $connexion->prepare($requete);
	$stmt->bind_param("i", $idArticle);
	$stmt->execute();
	$result = $stmt->get_result();
	if(!$ligne = $result->fetch_object()){
		mysqli_close($connexion);
		header('Location: ../admin/admin.php?msg=Article+est+introuvable');
		exit;
	}
?>