<?php
    // Au début de PHP : Déclarer les types dans les paramètres des fonctions
    declare(strict_types=1);

    require_once(__DIR__."/../../../Serveur/MVC/ControleurVoyages.php");
   
    $instanceCtr = ControleurVoyage::getControleurVoyage();
    echo $instanceCtr->CtrV_Actions();
?>