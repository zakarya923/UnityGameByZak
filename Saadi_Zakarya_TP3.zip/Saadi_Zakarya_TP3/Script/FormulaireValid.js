    let validerFormEnreg = () => {
        let pass = document.getElementById('Pass').value;
        let cpass = document.getElementById('ConfPassword').value;
        
        if (pass === cpass) {
            return true; 
        } else {
           
            alert("Les mots de passe ne correspondent pas !");
            return false; 
        }
    }

function rendreVisible(elem){
	document.getElementById(elem).style.display='block';
}

function rendreInvisible(elem){
	document.getElementById(elem).style.display='none';
}
