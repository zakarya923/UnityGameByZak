let listeLivres;

let chargerLivres = () => {
    // $.ajax({
    //     type : "GET",
    //     url : "serveur/donnees/bookstore.xml",
    //     dataType : "text",
    //     success : (reponse) => {
    //             alert(reponse);
    //     },
    //     fail : (e) => {
    //         alert("Gros problème");
    //     }
    // });
    fetch("serveur/donnees/bookstore.xml")
            .then(reponse => reponse.text())
            .then(stringLivres => {
                const parser = new DOMParser();
                listeLivres = parser.parseFromString(stringLivres, "application/xml");
                //console.log(listeLivres);
            })
            .catch(console.error);

}

let lister = () => {
    let tabLivres = listeLivres.getElementsByTagName('book');
    let contenu="";
    for(let unLivre of tabLivres){
        let titre = unLivre.getElementsByTagName('title')[0].firstChild.nodeValue;
        contenu+=(titre+"<br>");
    }
    document.getElementById('contenu').innerHTML = contenu;
    //$('#contenu').html(contenu);
}

$(document).ready(function () {
    $('#example').DataTable();
});

$(document).ready(function () {
    $('#exampleMembres').DataTable();
});