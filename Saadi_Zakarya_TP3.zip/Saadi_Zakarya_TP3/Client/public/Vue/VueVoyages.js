let montrerFormEnreg = () => {
    let form = `
    <div class="modal fade" id="enregModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <img id="imagelogo" src="../../../Client/public/images/logoProjet.png" alt="logo">
                    <h5 class="modal-title text-center" id="exampleModalLabel">Enregistrer voyage</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="formEnreg">
                        <div class="col-md-4">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image" required>
                        </div>
                        <div class="col-md-8">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="destination" class="form-label">Destination</label>
                            <input type="text" class="form-control" id="destination" name="destination" required>
                        </div>
                        <div class="col-md-6">
                            <label for="date_depart" class="form-label">Date de départ</label>
                            <input type="date" class="form-control" id="date_depart" name="date_depart" required>
                        </div>
                        <div class="col-md-6">
                            <label for="date_fin" class="form-label">Date de fin</label>
                            <input type="date" class="form-control" id="date_fin" name="date_fin" required>
                        </div>
                        <div class="col-md-6">
                            <label for="lieu_depart" class="form-label">Lieu de départ</label>
                            <input type="text" class="form-control" id="lieu_depart" name="lieu_depart" required>
                        </div>
                        <div class="col-md-6">
                            <label for="prix" class="form-label">Prix</label>
                            <input type="number" class="form-control" id="prix" name="prix" required>
                        </div>
                        <div class="col-12 mt-4 d-flex justify-content-center">
                            <button class="btn btn-primary" type="button" onClick="requeteEnregistrer();">Enregistrer</button>
                        </div>
                    </form>
                    
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
    `;
    document.getElementById('contenu').innerHTML = form;
    $('#enregModal').modal('show');
}



let remplirCard = (unVoyage) => {
    let rep = '<div class="col">';
    rep += '<div class="card">';
    rep += '<img src="serveur/pochettes/' + unVoyage.image + '" class="card-img-top" alt="...">';
    rep += '<div class="card-body cards-bg">';
    rep += '<h5 class="card-title">' + unVoyage.destination + '</h5>';
    rep += '<p class="card-text">Description: ' + unVoyage.description + '</p>';
    rep += '<p class="card-text">Lieu de départ : ' + unVoyage.lieu_depart + '</p>';
    rep += '<a href="#" class="btn btn-primary">Réserver</a>';
    rep += '<h2 class="">A partir de</h2>';
    rep += '<h3 class="card-price">' + unVoyage.prix + '</h3>';
    rep += '<div class="card-footer bg-transparent border-success">Depart le ' + unVoyage.date_depart + ' - ' + unVoyage.date_fin + '</div>';
    rep += ' </div>';
    rep += ' </div>';
    rep += ' </div>';

    return rep;
}
let afficherVoyages = (listeVoyages) => {
    let affichercards = '<div class="row">';
    for (let unVoyage of listeVoyages) {
        affichercards += remplirCard(unVoyage);
    }
    affichercards += '</div>';

    document.getElementById('affichercards').innerHTML = affichercards;
};

let remplirCardMembres = (unVoyage) => {
    let rep = '<div class="col">';
    rep += '<div class="card">';
    rep += '<img src="serveur/pochettes/' + unVoyage.image + '" class="card-img-top" alt="...">';
    rep += '<div class="card-body cards-bg">';
    rep += '<h5 class="card-title">' + unVoyage.destination + '</h5>';
    rep += '<p class="card-text">Description: ' + unVoyage.description + '</p>';
    rep += '<p class="card-text">Lieu de départ : ' + unVoyage.lieu_depart + '</p>';
    rep += ' <a href="#" onClick="ajouterPanier(' + unVoyage.id + ');"><i class="fa-solid fa-plus fa-beat-fade fa-xl" style="color: #000000;"></i></a>';
    rep += '<h2 class="">A partir de</h2>';
    rep += '<h3 class="card-price">' + unVoyage.prix + '</h3>';
    rep += '<div class="card-footer bg-transparent border-success">Depart le ' + unVoyage.date_depart + ' - ' + unVoyage.date_fin + '</div>';
    rep += ' </div>';
    rep += ' </div>';
    rep += ' </div>';

    return rep;
}
let afficherVoyagesMembres = (listeVoyages) => {
    let affichercards = '<div class="row">';
    for (let unVoyage of listeVoyages) {
        affichercards += remplirCardMembres(unVoyage);
    }
    affichercards += '</div>';

    document.getElementById('affichercardsMembres').innerHTML = affichercards;
};



let listerVoyages = (listeVoyages) => {
    let contenu = `
    <table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>NUMERO</th>
                <th>IMAGES</th>
                <th>DESTINATION</th>
                <th>DESCRIPTION</th>
                <th>DATE DE DEPART</th>
                <th>DATE DE FIN</th>
                <th>LIEU DE DEPART</th>
                <th>PRIX</th>
                <th>SUPP/MAJ</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>NUMERO</th>
                <th>IMAGES</th>
                <th>DESTINATION</th>
                <th>DESCRIPTION</th>
                <th>DATE DE DEPART</th>
                <th>DATE DE FIN</th>
                <th>LIEU DE DEPART</th>
                <th>PRIX</th>
                <th>SUPP/MAJ</th>

            </tr>
        </tfoot>
        <tbody>
`;
    for (let unVoyage of listeVoyages) {
        contenu += `
        <tr>
            <td>${unVoyage.id}</td>
            <td>${unVoyage.image}</td>
            <td>${unVoyage.destination}</td>
            <td>${unVoyage.description}</td>
            <td>${unVoyage.date_depart}</td>
            <td>${unVoyage.date_fin}</td>
            <td>${unVoyage.lieu_depart}</td>
            <td>${unVoyage.prix}</td>
            <td><button type="button" class="btn-close d-flex justify-content-center" aria-label="Close" onClick="requeteSupprimer(${unVoyage.id}, this);"></button></td>
        </tr>
    `;
    }
    contenu += `
        </tbody>
    </table>  
`;

    contenu += `
<div id="divFiche" class="d-flex align-items-center justify-content-center">
<form id="formFiche">
<button type="button" class="btn-close d-flex justify-content-center" aria-label="Close" onClick="rendreInvisible('divFiche')"></button>
<h3 class="modal-title">Mise à jour du Voyage</h3><br><br>
<div class="mb-2">
  <label for="idVoyage" class="form-label">Identifiant :</label>
  <input type="text" class="form-control" id="idVoyage" name="idVoyage">
</div>
<button type="button" class="btn btn-primary" onClick="obtenirFiche();">Envoyer</button>
</form>
</div>

<div id="divFormFiche"  style="position:absolute;top:10%;left:50%; display:none">
<form id="formFicheF">
<h3></h3><button type="button" class="btn-close d-flex justify-content-center" aria-label="Close" onClick="rendreInvisible('divFormFiche')"></button>
<br><br>
<input type="hidden" id="id" name="id">
<div class="mb-2">
  <label for="image" class="form-label">Image :</label>
  <input type="file" class="form-control" id="image" name="image">
</div>
<div class="mb-2">
  <label for="destination" class="form-label">Destination :</label>
  <input type="text" class="form-control" id="destination" name="destination">
</div>
<div class="mb-2">
  <label for="description" class="form-label">Description :</label>
  <textarea class="form-control" id="description" name="description" rows="4"></textarea>
</div>
<div class="mb-2">
  <label for="date_depart" class="form-label">Date de départ :</label>
  <input type="date" class="form-control" id="date_depart" name="date_depart">
</div>
<div class="mb-2">
  <label for="date_fin" class="form-label">Date de fin :</label>
  <input type="date" class="form-control" id="date_fin" name="date_fin">
</div>
<div class="mb-2">
  <label for="lieu_depart" class="form-label">Lieu de départ :</label>
  <input type="text" class="form-control" id="lieu_depart" name="lieu_depart">
</div>
<div class="mb-2">
  <label for="prix" class="form-label">Prix :</label>
  <input type="number" class="form-control" id="prix" name="prix">
</div>
<button type="button" class="btn btn-outline-warning" onClick="miseajour();">Modifier</button>
</form>
</div>  
`;
    document.getElementById('contenu').innerHTML = contenu;
}



function afficherFiche(donnees) {
    var unVoyage;
    if (donnees.OK) {
        unVoyage = donnees.fiche;
        $('#formFicheF h3:first-child').html("Fiche du voyage numéro " + unVoyage.id);
        $('#id').val(unVoyage.id);
        $('#destination').val(unVoyage.destination);
        $('#description').val(unVoyage.description);
        $('#date_depart').val(unVoyage.date_depart);
        $('#date_fin').val(unVoyage.date_fin);
        $('#lieu_depart').val(unVoyage.lieu_depart);
        $('#prix').val(unVoyage.prix);
        $('#divFormFiche').show();
        document.getElementById('divFormFiche').style.display = 'block';
    } else {
        $('#messages').html("Voyage " + $('#idVoyage').val() + " introuvable");
        setTimeout(function () { $('#messages').html(""); }, 5000);
    }
}



let listerMembres = (listeMembres) => {
    let contenu = `
    <div id="formContainer">
    <form id="formMembres">
        <table id="exampleMembres" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>Numero</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Rôle</th>
                    <th>Statut</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
`;

        for (let unMembres of listeMembres) {
            contenu += `
                <tr>
                    <td><input type="text" id="idMembres" name="idMembres" value="${unMembres.Idm}" readonly class="inputId"></td>
                    <td>${unMembres.Nom}</td>
                    <td>${unMembres.Prenom}</td>
                    <td>${unMembres.rôle}</td>
                    <td>${unMembres.statut}</td>
                    <td><button type="button" class="btn btn-outline-warning" onClick="obtenirFicheMembres();">Modifier Membres</button></td>
                </tr>
            `;
        }

        contenu += `
                    </tbody>
                </table>
            </form>
            </div>

            <div class="modal fade" id="divFormFicheMembres" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modifier un membres</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                <form id="formFicheM">
                    <div class="col-md-12">
                        <label for="idm" class="form-label">Identifiant</label>
                        <input type="text" class="form-control" id="idm" name="idm" value="" readonly>
                    </div>
                    <div class="col-md-12">
                        <label for="nom" class="form-label">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom" value="" readonly>
                    </div>
                    <div class="col-md-12">
                        <label for="prenom" class="form-label">Prénom</label>
                        <input type="text" class="form-control" id="prenom" name="prenom" value="" readonly>
                    </div>
                    <div class="col-md-12">
                        <label for="role" class="form-label">Rôle</label>
                        <input type="text" class="form-control" id="rôle" name="rôle" value="" >
                    </div>
                    <div class="col-md-12">
                        <label for="statut" class="form-label">Statut</label>
                        <input type="text" class="form-control" id="statut" name="statut" value="" >
                    </div>
                    <div class="col-12">
                        <span>&nbsp;</span>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit" onClick="miseajourMembres();">Modifier</button>
                    </div>
                </form>
                    </div>
                </div>
            </div>
        </div>
        `;


    document.getElementById('contenu').innerHTML = contenu;

}

function afficherFicheMembres(donnees) 
{
    var unMembres;
    if (donnees.OK) {
        unMembres = donnees.ficheMembres;
        $('#formFicheM h3:first-child').html("Fiche du voyage numéro " + unMembres.Idm);
        $('#idm').val(unMembres.Idm);
        $('#nom').val(unMembres.Nom);
        $('#prenom').val(unMembres.Prenom);
        $('#rôle').val(unMembres.rôle);
        $('#statut').val(unMembres.statut);
        $('#divFormFicheMembres').modal('show');
        } else {
        $('#messages').html("Voyage " + $('#idMembres').val() + "introuvable");
        setTimeout(function () { $('#messages').html(""); }, 5000);
    }
}



let afficherPanier = (listeVoyages) => {
    let panier = JSON.parse(localStorage.getItem("panier"));
    let nbArt = panier.length;
    let vuePanier = `
        <div class="card">
            <div class="row">
                <div class="col-md-8">
                    <div class="title">
                        <div class="row">
                            <div class="col">
                                <h4><b>Panier d'achats</b></h4>
                            </div>
                            <div class="col align-self-center text-right text-muted">${nbArt} articles</div>
                        </div>
                    </div> 
        `;
        let listeArticlesAchetes = [];
    panier.forEach(idArticle => {
        let article =listeVoyages.find(unVoyage => unVoyage.id == idArticle);
        if (article) {
            listeArticlesAchetes.push(article);
        } else {
            console.log(`L'article avec l'ID ${idArticle} n'existe pas dans la liste des voyages.`);
            alert(`L'article avec l'ID ${idArticle} n'existe pas dans la liste des voyages.`);
        }
    });
    let totalAchat = 0;
    let montantTotalCetArticle;
    for (let unVoyage of listeArticlesAchetes) {
        montantTotalCetArticle = parseFloat(unVoyage.prix);
        vuePanier += ` 
            <div class="row border-top border-bottom" id="paiementdiv">
                <div class="row align-items-center">
                    <div class="col-2"><img class="img-fluid" src="../../images_articles/${unVoyage.image}"></div>
                    <div class="col">
                        <div class="row text-muted">${unVoyage.destination}</div>
                    </div>
                    <div class="col"> <input type="number" id="qte" name="qte" min="1" max="100" value=1 onChange="ajusterTotalAchat(this,${unVoyage.prix}, ${montantTotalCetArticle});"></div>
                    <div class="col">${montantTotalCetArticle}$</div>
                    <div class="col"><div class="close closeBtn" onClick="enleverArticle(this,${unVoyage.id});">&#10005;</div></div>
                </div>
            </div>
        
        `;
        totalAchat += montantTotalCetArticle;
    }
    
    let montantTaxes = totalAchat * TAXES;
    let totalPayer = totalAchat + montantTaxes;

    vuePanier += `
            </div>
                    <div class="col-md-4 bg-info text-dark">
                        <div>
                            <h5><b>Facture</b></h5>
                        </div>
                        <hr>
                        <br/>
                        <div class="row">
                            <div class="col" style="padding-left:10;">${nbArt} ARTICLES</div>
                            <div id="totalAchat" class="col text-right">${totalAchat.toFixed(2)}$</div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col" style="padding-left:10;">MONTANT TAXES</div>
                            <div id="idTaxes" class="col text-right">${montantTaxes.toFixed(2)}$</div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col" style="padding-left:10;">MONTANT À PAYER</div>
                            <div id="totalPayer" class="col text-right">${totalPayer.toFixed(2)}$</div>
                        </div> 
                        </br>
                        <button class="btn btn-dark" onclick="payer();">PAYER</button>
                        <span id="payer"></span>
                        <br/> 
                        <div class="col-12 mt-4 d-flex justify-content-center">
                        <button class="btn btn-primary" type="button" onClick="remettrePanierZero();">Effacer le panier</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    $('#contenuPanier').html(vuePanier);
    document.getElementById("payer").innerHTML = "";
    let modalPanier = new bootstrap.Modal(document.getElementById('idModPanier'), {});
    modalPanier.show();
}

let remettrePanierZero = () => {
    localStorage.clear();
    alert("Le panier a été réinitialisé.");
    location.reload();
  };

let afficherMessage = (msg) => {
    document.getElementById('msg').innerHTML = msg;
    setTimeout(() => {
        document.getElementById('msg').innerHTML = "";
    }, 5000);
}

let montrerVue = (action, donnees) => {

    switch (action) {
        case "enregistrer":
        case "modifier":
        case "modifierMembres":
        case "enlever":
            if (donnees.OK) {
                afficherMessage(donnees.msg);
            } else {
                afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
            }
            break;
        case "lister":

            if (donnees.OK) {
                listerVoyages(donnees.listeVoyages);

            } else {
                afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
            }
            break;

        case "listerMembres":

            if (donnees.OK) {
                listerMembres(donnees.listeMembres);

            } else {
                afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
            }
            break;

        case "listercards":
            if (donnees.OK) {
                afficherVoyages(donnees.listeVoyages);

            } else {
                afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
            }
            break;
        case "listercardsMembres":
                if (donnees.OK) {
                    afficherVoyagesMembres(donnees.listeVoyages);
    
                } else {
                    afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
                }
                break;

        case "listerVoyagePanier":
                if (donnees.OK) {
                    afficherPanier(donnees.listeVoyages);
    
                } else {
                    afficherMessage("Problème côté serveur. Essaiez plus tard!!!");
                }
                break;

        case "fiche":
            if (donnees.OK) {
                afficherFiche(donnees);
            } else {
                afficherMessage("Voyage introuvable");
            }
            break;

        case "ficheMembres":
            if (donnees.OK) {
                afficherFicheMembres(donnees);
            } else {
                afficherMessage("Membre introuvable");
            }
            break;
    }


}