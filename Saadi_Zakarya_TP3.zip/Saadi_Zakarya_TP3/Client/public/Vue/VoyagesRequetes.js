const TAXES = 0.1556; // Constante représentant le taux de taxes
let panier = null; // Variable pour stocker le panier

let listeVoyages = null;
// Vérifier si le panier existe dans le localStorage, sinon le créer comme un tableau vide
if (localStorage.getItem("panier") == undefined) {
    localStorage.setItem("panier", '[]');
}

// Obtenir le nombre d'articles dans le panier et afficher le nombre dans l'élément avec l'ID 'nbart'
let nbart = JSON.parse(localStorage.getItem("panier")).length;
let afficherNbart = "(" + nbart + ")";
$('#nbart').html(afficherNbart);

// Fonction pour ajouter un article au panier
let ajouterPanier = (idArticle) => {
    panier = JSON.parse(localStorage.getItem("panier"));

    // Vérifier si l'article existe déjà dans le panier
    let trouve = panier.find(ida => {
        return idArticle == ida;
    });

    if (trouve == undefined) {
        panier.push(idArticle); // Ajouter l'article au panier
        localStorage.setItem("panier", JSON.stringify(panier)); // Mettre à jour le panier dans le localStorage
        ++nbart; // Incrémenter le nombre d'articles
        afficherNbart = "(" + nbart + ")";
        $('#nbart').html(afficherNbart); // Afficher le nombre d'articles dans l'élément avec l'ID 'nbart'
    } else {
        alert("Article existe déjà dans le panier");
    }
}

let mettreAJourLaFacture = (nouveauTotal) => {
    // Mettre à jour le montant total de l'achat affiché dans l'élément avec l'ID 'totalAchat'
    document.getElementById("totalAchat").innerText = nouveauTotal.toFixed(2) + "$";

    // Calculer le montant des taxes à partir du nouveau total
    let montantTaxes = nouveauTotal * TAXES;

    // Calculer le montant total à payer (total + taxes)
    let totalPayer = nouveauTotal + montantTaxes;

    // Mettre à jour les éléments affichant le montant des taxes et le total à payer
    document.getElementById("idTaxes").innerText = montantTaxes.toFixed(2) + "$";
    document.getElementById("totalPayer").innerText = totalPayer.toFixed(2) + "$";
}

let payer = () => {
    document.getElementById('idModPanier').style.display = 'none';
    let paymentModal = new bootstrap.Modal(document.getElementById('paiement'));
    paymentModal.show();

    setTimeout(() => {
        document.getElementById("payer").classList.remove("alert-animation");
        document.getElementById("payer").innerHTML = "";
    }, 5000);

}

let chargerVoyagesAJAX = () => {
    // Effectuer une requête AJAX
    $.ajax({
        type: "POST", // Utiliser la méthode POST pour envoyer les données
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php', // URL de l'endpoint à appeler
        data: { "action": "lister" }, // Données à envoyer avec la requête (ici, l'action "lister")
        dataType: "json", // Type de données attendu en réponse (ici, JSON)
        success: (listeVoyages) => {
            // Callback exécutée en cas de succès de la requête
            montrerVue("lister", listeVoyages); // Appeler la fonction montrerVue avec les données reçues
        },
        error: (xhr, status, error) => {
            // Callback exécutée en cas d'erreur de la requête
            console.log(xhr.responseText); // Afficher le message d'erreur dans la console
        }
    });
}

let chargerVoyagesPanier = () => {

    $.ajax({
        type: "POST",
        url: "../../../Serveur/pages/FenetreAdmin/Actionneur.php",
        data: { "action": "listerVoyagePanier" },
        dataType: "json",
        success: (listeVoyages) => {
            montrerVue("listerVoyagePanier", listeVoyages);
        },
        error: (xhr, status, error) => {
            console.log(xhr.responseText);
        }
    });
}

let chargerMembresAJAX = () => {
    // Effectuer une requête AJAX
    $.ajax({
        type: "POST", // Utiliser la méthode POST pour envoyer les données
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php', // URL de l'endpoint à appeler
        data: { "action": "listerMembres" }, // Données à envoyer avec la requête (ici, l'action "listerMembres")
        dataType: "json", // Type de données attendu en réponse (ici, JSON)
        success: (listeMembres) => {
            // Callback exécutée en cas de succès de la requête
            montrerVue("listerMembres", listeMembres); // Appeler la fonction montrerVue avec les données reçues
        },
        error: (xhr, status, error) => {
            // Callback exécutée en cas d'erreur de la requête
            console.log(xhr.responseText); // Afficher le message d'erreur dans la console
        }
    });
}

let requeteEnregistrer = () => {
    $('#msg').show(); // Afficher l'élément avec l'ID 'msg'
    let formVoyage = new FormData(document.getElementById('formEnreg')); // Récupérer les données du formulaire avec l'ID 'formEnreg'
    formVoyage.append('action', 'enregistrer'); // Ajouter une clé 'action' avec la valeur 'enregistrer' aux données du formulaire
    $.ajax({
        type: 'POST', // Utiliser la méthode POST pour envoyer les données
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php', // URL de l'endpoint à appeler
        data: formVoyage, // Données à envoyer avec la requête (les données du formulaire)
        contentType: false, // Ne pas définir le type de contenu de la requête (laisser le navigateur le déterminer automatiquement)
        processData: false, // Ne pas traiter les données (les laisser telles quelles)
        dataType: 'json', // Type de données attendu en réponse (ici, JSON)
        success: function (reponse) {
            // Callback exécutée en cas de succès de la requête
            montrerVue("enregistrer", reponse); // Appeler la fonction montrerVue avec les données reçues
            setTimeout(function () {
                $('#msg').hide(); // Cacher l'élément avec l'ID 'msg' après 3 secondes
            }, 3000);
        },
        error: function (xhr, status, error) {
            // Callback exécutée en cas d'erreur de la requête
            console.log(xhr.responseText); // Afficher le message d'erreur dans la console
        }
    });
}

let requeteSupprimer = (idvoy, bouton) => {
    let confirmation = confirm("Êtes-vous sûr de vouloir supprimer ce voyage ?");
    if (confirmation) {
        $.ajax({
            type: "POST",
            url: "../../../Serveur/pages/FenetreAdmin/Actionneur.php",
            data: { "action": "enlever", "idVoyage": idvoy },
            dataType: "json",
            success: (reponse) => {
                montrerVue("enlever", reponse);
                // Supprimer la ligne du voyage dans le tableau HTML
                let ligneVoyage = bouton.closest("tr");
                ligneVoyage.remove();
            },
            error: (xhr, status, error) => {
                console.log(xhr.responseText);
            }
        });
    }
}

function obtenirFiche() {
    document.getElementById('example').style.display = 'none';
    document.getElementById('formFiche').style.display = 'none';
    $('#divFiche').hide();
    var leForm = document.getElementById('formFiche');
    var formVoyage = new FormData(leForm);
    formVoyage.append('action', 'fiche');
    $.ajax({
        type: 'POST',
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php',
        data: formVoyage,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (reponse) {
            montrerVue("fiche", reponse);
        },
        error: (xhr, status, error) => {
            console.log(xhr.responseText);
        }
    });
}

function miseajour() {
    $('#msg').show();
    var leForm = document.getElementById('formFicheF');
    var formVoyage = new FormData(leForm);
    formVoyage.append('action', 'modifier');
    $.ajax({
        type: 'POST',
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php',
        data: formVoyage,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (reponse) {
            $('#divFormFiche').hide();
            montrerVue("modifier", reponse);
            setTimeout(function () {
                $('#msg').hide();
            }, 3000);
        },
        error: (xhr, status, error) => {
            console.log(xhr.responseText);
        }
    });
}

function miseajourMembres() {
    $('#msg').show();
    var leForm = document.getElementById('formFicheM');
    var formMembres = new FormData(leForm);
    formMembres.append('action', 'modifierMembres');
    $.ajax({
        type: 'POST',
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php',
        data: formMembres,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (reponse) {
            montrerVue("modifierMembres", reponse);
            location.reload();
            setTimeout(function () {
                $('#msg').hide();
            }, 3000);
        },
        error: (xhr, status, error) => {
            console.log(xhr.responseText);
        }
    });
}

function obtenirFicheMembres() {
    var leForm = document.getElementById('formMembres');
    var formMembres = new FormData(leForm);
    formMembres.append('action', 'ficheMembres');
    $.ajax({
        type: 'POST',
        url: '../../../Serveur/pages/FenetreAdmin/Actionneur.php',
        data: formMembres,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (reponse) {
            montrerVue("ficheMembres", reponse);
            console.log("La fonction obtenirFicheMembres() a été appelée !");
        },
        error: (xhr, status, error) => {
            console.log(xhr.responseText);
            console.log("La fonction obtenirFicheMembres() n'a pas ete appelle !");

        }
    });
}

let enleverArticle = (btnClose, idArticleEnlever) => {
    let montantArticle;

    // Obtenir le montant de l'article à enlever
    if (btnClose.parentNode.previousSibling.nodeType == 3) {
        montantArticle = parseFloat(btnClose.parentNode.previousSibling.previousSibling.firstChild.nodeValue);
    } else {
        montantArticle = parseFloat(btnClose.parentNode.previousSibling.firstChild.nodeValue);
    }

    let ancienTotal = parseFloat(document.getElementById("totalAchat").innerText);
    let nouveauTotal = ancienTotal - montantArticle; // Mettre à jour le total de l'achat

    // Enlever l'article du visuel du panier
    let articleEnleverVisuelPanier = btnClose.parentNode.parentNode;
    articleEnleverVisuelPanier.parentNode.remove(articleEnleverVisuelPanier);

    // Mettre à jour le panier dans le localStorage
    panier = JSON.parse(localStorage.getItem("panier"));
    let nouveauPanier = panier.filter(idArticlePanier => {
        return idArticlePanier != idArticleEnlever;
    });

    if (nouveauPanier.length == panier.length) {
        alert("L'article " + idArticleEnlever + " n'existe pas");
    } else {
        localStorage.setItem("panier", JSON.stringify(nouveauPanier));
        --nbart; // Décrémenter le nombre d'articles
        afficherNbart = "(" + nbart + ")";
        $('#nbart').html(afficherNbart);
        mettreAJourLaFacture(nouveauTotal);
    }
}


let ajusterTotalAchat = (elemInput, prix, montantActuel) => {
    let ancienMontant;
    let qte = elemInput.value;
    let montantTotalCetArticle = (qte * prix);

    // Vérifier le type de nœud suivant pour mettre à jour le montant total de cet article
    if (elemInput.parentNode.nextSibling.nodeType == 3) {
        ancienMontant = parseFloat(elemInput.parentNode.nextSibling.nextSibling.firstChild.nodeValue);
        elemInput.parentNode.nextSibling.nextSibling.firstChild.nodeValue = montantTotalCetArticle + "$";
    } else {
        ancienMontant = parseFloat(elemInput.parentNode.nextSibling.firstChild.nodeValue);
        elemInput.parentNode.nextSibling.firstChild.nodeValue = montantTotalCetArticle + "$";
    }

    // Mettre à jour la facture
    let ancienTotal = parseFloat(document.getElementById("totalAchat").innerText);
    let nouveauTotal = (ancienTotal - ancienMontant) + montantTotalCetArticle;
    mettreAJourLaFacture(nouveauTotal);
}


const posterFormAvecFETCH = async (url, formData) => {
    const optionsFetch = {
        method: "POST",
        body: formData
    };
    const reponse = await fetch(url, optionsFetch);
    if (!reponse.ok) {
        const messageErreur = await reponse.text();
        throw new Error(messageErreur);
    }
    return reponse.json();
}

const chargerVoyagesFETCH = async () => {
    const url = "Serveur/MVC/ControleurVoyages.php";
    const formData = new FormData();
    formData.append('action', 'lister');
    const listeVoyages = await posterFormAvecFETCH(url, formData);
    montrerVue("lister", listeVoyages);
}

