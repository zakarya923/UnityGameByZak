<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accueil</title>
    <link id="ic" rel="icon" href="Client/public/Icone/logoProjet.ico" type="image/x-icon">
    <link rel="stylesheet" href="Client/public/CSS/Style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="Script/FormulaireValid.js"></script>
        <script src="Client/public/Vue/VueVoyages.js"></script>
        <script src="Client/public/Vue/VoyagesRequetes.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script>
    let chargerVoyages = () => {
        
      $.ajax({
          type: "POST",
          url: "Serveur/pages/FenetreAdmin/Actionneur.php",
          data: {"action": "listercards"},
          dataType: "json",
          success: (listeVoyages) => {
              montrerVue("listercards", listeVoyages);
          },
          error: (xhr, status, error) => {
              console.log(xhr.responseText);
          }
      });
    }
    document.addEventListener("DOMContentLoaded", chargerVoyages);
  </script>
</head>

<body>
    <!-- -------------------------------------------------MENU---------------------------------------------------- -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid ">
            <a class="navbar-brand" href="#">
                <img src="Client/public/images/logoProjet.png" alt="Logo" class="logo">
            </a>
            <a class="navbar-brand" href="#">Menu</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="modal" data-bs-target="#FormEnreg" href="#">Devenir
                            Membre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="Conn" data-bs-toggle="modal" data-bs-target="#FormConn" href="#">Se Connecter</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- --------------------------------------------DIAPORAMA----------------------------------------------------------------------------- -->
    <div id="CarouselZakarya" class="carousel slide">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#CarouselZakarya" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#CarouselZakarya" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#CarouselZakarya" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner carousel-container">
            <div class="carousel-item active c-item">
                <img src="Client/public/images/Paysage.jpg" class="d-block w-100 c-img" alt="...">
                <div class="carousel-caption top-0 mt-4 d-none d-md-block">
                    <p class="mt-5 fs-3 text-uppercase">Vient decouvrir nos Circuit les plus connus</p>
                    <h1 class="display-1 fw-bolder text text-capitalize">Chez Dolla Travel !</h1>
                </div>
            </div>
            <div class="carousel-item c-item">
                <img src="Client/public/images/Paysage1.jpg" class="d-block w-100 c-img" alt="...">
                <div class="carousel-caption top-0 mt-4 d-none d-md-block">
                    <p class="mt-5 fs-3 text-uppercase">Faites nous confiances, voyager ! </p>
                    <h1 class="display-1 fw-bolder text text-capitalize">En toute tranquillité</h1>
                </div>
            </div>
            <div class="carousel-item c-item">
                <img src="Client/public/images/Paysage2.jpg" class="d-block w-100 c-img" alt="...">
                <div class="carousel-caption top-0 mt-4 d-none d-md-block">
                    <p class="mt-5 fs-3 text-uppercase">Pas besoin d'Economiser</p>
                    <h1 class="display-1 fw-bolder text text-capitalize">A bon prix</h1>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#CarouselZakarya" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#CarouselZakarya" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div><br>

    <!-- -------------------------------------------CARDS--------------------------------------------------------------------------------------------------- -->
   <div class="container" id="affichercards"></div>

    <!-- ------------------------------------------FORMULAIRE DE MEMBRE------------------------------------------------------------------------------------------------------------- -->
    <div class="modal fade" id="FormEnreg" tabindex="-1" aria-labelledby="FormEnregLabel" aria-hidden="true">

        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="logo">
                    <img id="imagelogo" src="Client/public/images/logoProjet.png" alt="logo">
                </div>
                <div class="modal-header">
                    <h5 class="modal-title" id="FormEnregLabel">Etre Membre</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <form class="row g-3 form" id="formEnreg" action="Serveur/pages/FenetreMembre/InscrireUnMembre.php" method="POST" onSubmit="return validerFormEnreg();">

                    <div class="col-md-3">
                        <label for="prenom" class="form-label">Prénom</label>
                        <input type="text" class="form-control" id="Prenom" name="Prenom" value="" required>
                    </div>

                    <div class="col-md-4">
                        <label for="nom" class="form-label">Nom</label>
                        <input type="text" class="form-control" id="Nom" name="Nom" value="" required>
                    </div>

                    <div class="col-md-4 Courriel">
                        <label for="mail" class="form-label">Courriel</label>
                        <div class="input-group has-validation">
                            <span class="input-group-text" id="inputGroupPrepend">@</span>
                            <input type="text" class="form-control" id="Courriel" name="Courriel"
                                aria-describedby="inputGroupPrepend" required>
                            <div class="invalid-feedback">
                                .
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 MDP">
                        <label for="Pass" class="form-label">Mot de passe</label>
                        <input type="password" class="form-control" id="Pass" name="Pass" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[-_])[a-zA-Z\d-_]{8,10}$">
                        <div class="invalid-feedback">
                            Veuillez fournir un mot de passe valide (entre 8 et 10 caractères qui incluent des lettres
                            minuscules, majuscules, des chiffres et les caractères -_). </div>
                    </div>

                    <div class="col-md-6 CMDP">
                        <label for="ConfPassword" class="form-label">Confirmation du mot de passe</label>
                        <input type="password" class="form-control" id="ConfPassword" name="ConfPassword" required>
                    </div>

                    <div class="col-md-4 mb-3 Feminin">
                        <input type="radio" class="form-check-input" id="feminin" value="F" name="Sexe">
                        <label class="form-check-label" for="feminin">Féminin</label>
                    </div>
                    <div class="col-md-4 mb-3 Masculin">
                        <input type="radio" class="form-check-input" id="masculin" value="M" name="Sexe">
                        <label class="form-check-label" for="masculin">Masculin</label>
                    </div>
                    <div class="col-md-4 DateNaiss">
                        <label for="date" class="form-label">Date de naissance</label>
                        <input type="date" class="form-control" id="DateNaissance" name="DateNaissance">
                    </div>
                    <div class="col-12">
                        <button class="btn btn-primary" type="submit">Envoyer le formulaire !</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <!------------------------------------------ FORMULAIRE DE CONNEXION-------------------------------------------- -->
    <div class="modal fade" id="FormConn" tabindex="-1" aria-labelledby="FormConnLabel" aria-hidden="true">

        <div class="modal-dialog">
            <div class="modal-content">
            <div class="logo">
                    <img id="imagelogo" src="Client/public/images/logoProjet.png" alt="logo">
                </div>
                <div class="modal-header">
                    <h5 class="modal-title" id="FormConnLabel">Formulaire de Connexion </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
          
                <div class="modal-body">
                    <form class="row g-3" id="formConnexion" action="Serveur/pages/FormulairesConnDeco/FenetresConnexion.php"
                        method="POST">
                        <div class="col-md-4">
                            <label for="courriel" class="form-label">Courriel</label>
                            <input type="email" class="form-control" id="courriel" name="courriel" value="" required>
                        </div>
                        <div class="col-md-6">
                            <label for="pass" class="form-label">Mot Passe</label>
                            <input type="password" class="form-control" id="Password" name="Password" required>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary" type="submit">Connexion</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
    <!-- ------------------------------------------SCRIPT JAVASCRIPT--------------------------------------------------------------- -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>




    <!-- ------------------------------------------------------------------------------------------------------------------------------ -->

</body>